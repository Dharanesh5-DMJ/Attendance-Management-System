<?php
$conn = new mysqli('localhost','root','','attendance_db');
?>