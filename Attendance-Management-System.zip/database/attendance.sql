-- SQL database
CREATE DATABASE attendance_db;