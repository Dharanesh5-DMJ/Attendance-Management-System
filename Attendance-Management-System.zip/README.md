# Attendance Management System
Built with PHP, MySQL, HTML, CSS, JS